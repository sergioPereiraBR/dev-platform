#   src/dev_platform/main.py
from interface.cli.user_commands import cli


if __name__ == "__main__":
    cli()
